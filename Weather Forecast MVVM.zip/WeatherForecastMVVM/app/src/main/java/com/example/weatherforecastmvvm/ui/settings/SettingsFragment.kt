package com.example.weatherforecastmvvm.ui.settings

import androidx.fragment.app.Fragment

class SettingsFragment: Fragment() {
}