package com.example.weatherforecastmvvm.ui.weather.future.list

import androidx.lifecycle.ViewModel

class FutureListWeatherViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}