package com.example.weatherforecastmvvm.ui.weather.current

import androidx.lifecycle.ViewModel

class CurrentWeatherViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}